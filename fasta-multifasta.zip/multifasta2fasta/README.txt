README
------

This script allows you to convert a multifasta file into multiple fasta files.
Nothing less.
Nothing more.
