README
------

This script allows you to convert a directory containing fasta files into a multifasta file.
Nothing less.
Nothing more.
